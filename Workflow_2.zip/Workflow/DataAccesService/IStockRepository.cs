﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesService
{
    public interface IStockRepository
    {
        void SaveStocks(List<Stock> stocks);

        void SaveStockPrices(List<StockPrice> stockPrices);

        Dictionary<string, decimal> GetPriceForSecurityFromSupplier(DateTime date, string ticker, string supplier);

        Dictionary<string, decimal> GetPriceForSecurityFromAllSuppliers(DateTime date, string ticker);
    }
}
