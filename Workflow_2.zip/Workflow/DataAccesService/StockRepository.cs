﻿using Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesService
{
    public class StockRepository : IStockRepository
    {
        //TODO represents table in SQL db, can be maped using EF
        private List<Stock> _stocks;

        //TODO represents table in SQL db, can be maped using EF
        private List<StockPrice> _stockPrices = new List<StockPrice>();

        private string[] suppliersInOrder;
        
        public void SaveStocks(List<Stock> stocks)
        {
            _stocks = stocks;
            var suppliers = ConfigurationManager.AppSettings["SUPPLIERSORDER"];
            suppliersInOrder = suppliers.ToLower().Split(',');
        }

        public void SaveStockPrices(List<StockPrice> stockPrices)
        {
            _stockPrices.AddRange(stockPrices);            
        }

        public Dictionary<string, decimal> GetPriceForSecurityFromSupplier(DateTime date, string ticker, string supplier)
        {
            var query = _stockPrices.Where(x => x.Date == date)
                                    .Where(x => x.Name == ticker)
                                    .Where(x => x.Supplier == supplier)
                                    .Select(x => x).FirstOrDefault();
            return new Dictionary<string, decimal>()
            {
                { query.Name, query.Close.Value }
            };
        }

        public Dictionary<string, decimal> GetPriceForSecurityFromAllSuppliers(DateTime date, string ticker)
        {
            for (int i = 0; i < suppliersInOrder.Length; i++)
            {
                var price = _stockPrices.Where(x => x.Date == date)
                                        .Where(x => x.Name == ticker)
                                        .Where(x => x.Supplier == suppliersInOrder[i])
                                        .FirstOrDefault();
                if (price != null && !price.IsInterpolated)
                {
                    return new Dictionary<string, decimal>()
                    {
                        { price.Name, price.Close.Value }
                    };
                }
            }
            return GetPriceForSecurityFromSupplier(date, ticker, suppliersInOrder[0]);
        }

        public Dictionary<string, decimal> GetPriceForAllSecuritiesFromSupplier(DateTime date, string supplier, string sector, string subIndustry, Func<StockPrice, bool> realPriceFilter, IEnu<StockPrice> pricesToFilter = null)
        {
            if (pricesToFilter == null)
            {
                pricesToFilter = _stockPrices;
            }

            var stockToReturn = _stocks.Where(x => x.Sector == sector)
                                       .Where(x => x.SubIndustry == subIndustry).ToList();

            return pricesToFilter.Where(x => x.Date == date)
                                      .Where(x => x.Supplier == supplier)
                                      .Where(x => stockToReturn.Any(y => y.Ticker == x.Name))
                                      .Where(realPriceFilter)
                                      .ToDictionary(key => key.Name, value => value.Close.Value); 
        }

        public Dictionary<string, decimal> GetPriceForForAllSecuritiesFromAllSuppliers(DateTime date, string sector, string subIndustry)
        {
            Dictionary<string, decimal>[] pricesPerSupplier = new Dictionary<string, decimal>[suppliersInOrder.Length];

            Func<StockPrice, bool> realPriceSelector = (x) => x.IsInterpolated == false;
            Func<StockPrice, bool> missingPriceSelector = (x) => x.IsInterpolated == true;

            pricesPerSupplier[0] = GetPriceForAllSecuritiesFromSupplier(date, suppliersInOrder[0], sector, subIndustry, realPriceSelector);
            var missingPrices = GetPriceForAllSecuritiesFromSupplier(date, suppliersInOrder[0], sector, subIndustry, missingPriceSelector);

            for (int i = 1; i < suppliersInOrder.Length; i++)
            {
                pricesPerSupplier[i] = GetPriceForAllSecuritiesFromSupplier(date, suppliersInOrder[i], sector, subIndustry, missingPrices.to);

                missingPrices = missingPrices.


            }
            return GetPriceForSecurityFromSupplier(date, ticker, suppliersInOrder[0]);


            return new Dictionary<string, decimal>();
        }
    }
}
