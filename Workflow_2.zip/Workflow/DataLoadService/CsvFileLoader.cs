﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.IO;

namespace DataLoadService
{
    public class CsvFileLoader : IStockPriceLoader
    {
        private readonly string _fileName;
        private readonly string _supplier;

        public CsvFileLoader(string filename, string supplier)
        {
            _fileName = filename;
            _supplier = supplier;
        }        

        public List<StockPrice> LoadStockPrices()
        {
            var final = new List<StockPrice>();

            string[] data = File.ReadAllText(_fileName).Trim().Split('\n');

            for (int i = 0; i < data.Length; i++)
            {
                if (i == 0)
                    continue;

                string[] values = data[i].Split(',');

                DateTime date = Convert.ToDateTime(values[0]);

                Decimal? close = null;
                decimal closeValue;
                if (Decimal.TryParse(values[1].ToString(), out closeValue))
                {
                    close = closeValue;
                }

                string name;
                if (values[2].EndsWith("\r"))
                {
                    name = values[2].Remove(values[2].Length - 1);
                }
                else
                {
                    name = values[2];
                }
                
                final.Add(new StockPrice(name, _supplier, close, date));
            }

            //using (TextFieldParser parser = new TextFieldParser(_fileName))
            //{
            //    parser.TextFieldType = FieldType.Delimited;
            //    parser.SetDelimiters(",");
            //    while (!parser.EndOfData)
            //    {
            //        string[] fields = parser.ReadFields();
            //        for (int i = 0; i < fields.Length; i++)
            //        {
            //            if (i == 0)
            //                continue;

            //            string name = values[0];
            //            DateTime date = Convert.ToDateTime(values[1]);
            //            Decimal? close = null;

            //            decimal closeValue;
            //            if (Decimal.TryParse(values[2].ToString(), out closeValue))
            //            {
            //                close = closeValue;
            //            }

            //            final.Add(new StockPrice(name, close, date));

            //        }
            //    }
            //}



            //using (var reader = new StreamReader(_fileName))
            //{
            //    List<StockPrice> final = new List<StockPrice>();
            //    while (!reader.EndOfStream)
            //    {
            //        var line = reader.ReadLine();
            //        var values = line.Split(',');

            //        string name = values[0];   
            //        DateTime date = Convert.ToDateTime(values[1]);
            //        Decimal? close = null;

            //        decimal closeValue;
            //        if (Decimal.TryParse(values[2].ToString(), out closeValue))
            //        {
            //            close = closeValue;
            //        }

            //        final.Add(new StockPrice(name, close, date));
            //    }
            //    return final.AsEnumerable<StockPrice>();
            //}

            return final;
        }
    }
}
