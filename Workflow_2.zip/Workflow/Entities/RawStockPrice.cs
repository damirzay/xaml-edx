﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public struct RawStockPrice
    {
        public string Name { get; set; }
        public string Close { get; set; }
        public DateTime Date { get; set; }
    }
}
