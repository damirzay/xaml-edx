﻿using DataAccesService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationService
{
    public class VolatilityCalculator : IVolatilityCalculator
    {
        IStockRepository _stockRepository;

        public VolatilityCalculator(IStockRepository stockRepository)
        {
            _stockRepository = stockRepository;
        }


        public decimal CalculateVolatility(DateTime startDate, DateTime endDate, string ticker, string supplier = null)
        {
            List<decimal> prices = _stockRepository.GetPricesForSecurityForDates(startDate, endDate, ticker, supplier);
            List<double> logReturns = new List<double>();
            List<double> squaredDeviations = new List<double>();

            for (int i = 1; i < prices.Count; i++)
            {
                var priceReturn = prices[i] / prices[i - 1];               
                logReturns.Add(Math.Log((double)priceReturn));
            }

            double returnAverage = logReturns.Average();

            for (int i = 0; i < logReturns.Count; i++)
            {
                squaredDeviations.Add((logReturns[i] - returnAverage) * (logReturns[i] - returnAverage));
            }

            double variance = squaredDeviations.Average();

            return (decimal)Math.Sqrt(variance);
        }
    }
}
