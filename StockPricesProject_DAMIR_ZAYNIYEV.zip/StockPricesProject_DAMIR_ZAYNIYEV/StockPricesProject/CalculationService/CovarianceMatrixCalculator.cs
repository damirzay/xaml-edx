﻿using DataAccesService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationService
{
    public class CovarianceMatrixCalculator : ICovarianceMatrixCalculator
    {
        //TODO implement custom type to store matrix, add collection to store labels of rows and columns, for now Stocks are alphabetically ordered
        IStockRepository _stockRepository;

        public CovarianceMatrixCalculator(IStockRepository stockRepository)
        {
            _stockRepository = stockRepository;
        }

        public decimal[,] CalculateCovarianceMatrix(DateTime startDate, DateTime endDate, string supplier = null)
        {
            List<string> allStocks = _stockRepository.GetAllStockTickers();
            int numberOfStocks = allStocks.Count;

            List<decimal>[] deviations = new List<decimal>[numberOfStocks];
            decimal[,] covarianceMatrix = new decimal[numberOfStocks, numberOfStocks];

            for (int i = 0; i < numberOfStocks; i++)
            {
                //TODO add query to repository to get prices for all stocks for dates in range from all suppliers
                var prices = _stockRepository.GetPricesForSecurityForDates(startDate, endDate, allStocks[i], supplier);
                var mean = prices.Average();
                deviations[i] = prices.Select(x => x - mean).ToList();
            }

            //TODO add optimisation not to calcalate simetrical element twice
            for (int i = 0; i < numberOfStocks; i++)
            {
                for(int j = 0; j < numberOfStocks; j++)
                {
                    var covariance = getCovariance(deviations[i], deviations[j]);                   
                    covarianceMatrix[i, j] = covariance;                    
                }
            }

            return covarianceMatrix;
        }

        private decimal getCovariance(List<decimal> list1, List<decimal> list2)
        {
            List<decimal> multiplication = new List<decimal>();
            int length = list1.Count;

            for (int i = 0; i < length; i++)
            {
                multiplication.Add(list1[i] * list2[i]);
            }

            return multiplication.Sum() / (length - 1);
        }
    }
}
