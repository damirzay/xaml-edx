﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAccesService;
using Moq;
using System.Collections.Generic;
using CalculationService;

namespace CalculationService.Test
{
    [TestClass]
    public class ReturnCalculatorTest
    {
        IStockRepository _stockRepositary;

        [TestMethod]
        public void ReturnShouldBeZeroForTheSameDate()
        {

            var repoMock = new Mock<IStockRepository>();
            Dictionary<string, decimal> mocReturn = new Dictionary<string, decimal>() { { "TEST", 1} };
            repoMock.Setup(r => r.GetPricesForSecuritiesForSingleDate(It.IsAny<DateTime>(), "TEST", null, null, null )).Returns(mocReturn);

            _stockRepositary = repoMock.Object;
            
            // Arrange
            var sut = new ReturnCalculator(_stockRepositary);
            
            // Act
            var result = sut.CalculatePriceReturns(DateTime.Now, DateTime.Now, "TEST", null, null, null);

            // Assert
            Assert.IsTrue(result.Count == 1);
            Assert.AreEqual(result["TEST"], 0);
        }
    }
}
