﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using DataLoadService;

namespace Workflow
{
    class Program
    {
       static void Main(string[] args)
        {
            WorkFlow wF = new WorkFlow();
            wF.Run();
        }
            }
}
