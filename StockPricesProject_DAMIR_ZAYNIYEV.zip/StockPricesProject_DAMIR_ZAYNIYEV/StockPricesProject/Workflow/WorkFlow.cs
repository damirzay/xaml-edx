﻿using CalculationService;
using DataAccesService;
using DataLoadService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;
using Unity.Lifetime;

namespace Workflow
{
    public class WorkFlow
    {
        IUnityContainer Container;

        private IAllSupplierStockPriceLoader _allSuppliersStockPriceLoader;
        private ISecuritiesLoader _securitiesLoader;
        private IStockRepository _stockRepositary;
        private IInterpolationService _interpolationService;
        private IReturnCalculator _returnCalculator;
        private IVolatilityCalculator _volatilityCalculator;
        private ICovarianceMatrixCalculator _covarianceMatrixCalculator;
        private IParsingService _parsingService;

        public void Run()
        {
            //TODO use IOC contaner to register Class to interface mappings and to new up instances
            ConfigureContainer();

            _stockRepositary = Container.Resolve<StockRepository>();
            _interpolationService = Container.Resolve<InterpolationService>();
            _parsingService = Container.Resolve<IParsingService>();

            _allSuppliersStockPriceLoader = new AllSuppliersStockPriceLoader(_stockRepositary, _interpolationService, _parsingService);

            var jsonFile = ConfigurationManager.AppSettings["SECURITIES"];
            _securitiesLoader = new SecuritiesLoader(jsonFile, _stockRepositary);
            _securitiesLoader.LoadSecurities();
                
            _allSuppliersStockPriceLoader.LoadAllSupplierStockPrices();


            DateTime Sdate = DateTime.ParseExact("08/01/2018", "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            DateTime Edate = DateTime.ParseExact("17/01/2018", "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            var prices = _stockRepositary.GetPricesForSecuritiesForSingleDate(Sdate, null, null, null, null);
            //prices.ContainsKey()

            var prices1 = _stockRepositary.GetPricesForSecurityForDates(Sdate, Edate, "AAL", "alice");
            var prices2 = _stockRepositary.GetPricesForSecurityForDates(Sdate, Edate, "AAL", null);

            _returnCalculator = new ReturnCalculator(_stockRepositary);
            var temp = _returnCalculator.CalculatePriceReturns(Sdate, Edate, null, "alice");

            _volatilityCalculator = new VolatilityCalculator(_stockRepositary);
            var volatility = _volatilityCalculator.CalculateVolatility(Sdate, Edate, "AAL", "alice");

            _covarianceMatrixCalculator = new CovarianceMatrixCalculator(_stockRepositary);
            var covarianceMatrix = _covarianceMatrixCalculator.CalculateCovarianceMatrix(Sdate, Edate, "alice");
        }

        private void ConfigureContainer()
        {
            Container = new UnityContainer();
            Container.RegisterType<IStockRepository, StockRepository>(new ContainerControlledLifetimeManager());
            Container.RegisterType<IInterpolationService, InterpolationService>(new ContainerControlledLifetimeManager());
            Container.RegisterType<IParsingService, ParsingService>(new ContainerControlledLifetimeManager());

        }
    }
}
