I have got separate project for each functionality with corresponding project names.
Description and Future development:
Add more Unit abd Integarations tests

Calculation Service: 
1) All required functions are implemented as they can be exposed as WebAPI, i.e. data is obtained after method calls.
2) If exposed as WebAPI, I need to add JSON serialization of matrix.
3) If we will be calling them only internally, implementation can be changed to require data i.e. caller to provide, so that Calculation Service doesn�t depend on Data Access Layer.

Data Access and Persistence:
1)Store data in SQL tables rewrite queries using SQL with Dapper or other fast ORM.
If EF is used current queries should work.
2) Add query to get Prices for all stocks from all suppliers for given range of dates.

DataLoadService:
1) Should be run separately, scheduled or event driven. Data persistence should be added, i.e. storing data in database.
2) Parsing and Interpolation services from DataLoadService can be moved to separate Common assemblies
