﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesService
{
    public interface IStockRepository
    {
        void SaveStocks(List<Stock> stocks);

        void SaveStockPrices(List<StockPrice> stockPrices);

        Dictionary<string, decimal> GetPricesForSecuritiesForSingleDate(DateTime priceDate, string ticker=null, string supplier=null, string sector=null, string subIndustry=null);

        List<decimal> GetPricesForSecurityForDates(DateTime startDate, DateTime endDate, string ticker, string supplier);

        List<string> GetAllStockTickers();
    }
}
