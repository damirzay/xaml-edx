﻿using DataAccesService;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLoadService
{
    public class AllSuppliersStockPriceLoader : IAllSupplierStockPriceLoader
    {
        private IStockPriceLoader _loader;
        private readonly IStockRepository _stockRepository;
        private readonly IInterpolationService _interpolationService;
        private readonly IParsingService _parsingService;

        public AllSuppliersStockPriceLoader(IStockRepository stockRepository, IInterpolationService interpolationService, IParsingService parsingService)
        {
            _stockRepository = stockRepository;
            _interpolationService = interpolationService;
            _parsingService = parsingService;
        }

        public void LoadAllSupplierStockPrices()
        {
            var priceSuppliersSettings = ConfigurationManager.GetSection("PriceSuppliersSettings") as NameValueCollection;

            if (priceSuppliersSettings.Count == 0)
            {
                //TODO Log error and / or throw exception / report Error about missing configuration for suppliers
            }
            else
            {
                foreach (var key in priceSuppliersSettings.AllKeys)
                {
                    string supplier = key.ToLower();
                    string fileName = priceSuppliersSettings[key];

                    string extention = Path.GetExtension(fileName);
                    if(extention == ".csv")
                    {
                        _loader = new CsvFileLoader(fileName, supplier, _parsingService);                        
                    }
                    else if(extention == ".xml")
                    {
                        _loader = new XmlFileLoader(fileName, supplier);
                    }
                    else
                    {
                        _loader = new ExcelFileLoader(fileName, supplier);
                    }

                    var stockPrices = _loader.LoadStockPrices();
                    _interpolationService.InterpolateStockPrices(stockPrices);

                    //Add checks for data consistency, i.e. we have 38 stocks with prices with no statical data in Securities.json
                    _stockRepository.SaveStockPrices(stockPrices);
                }
            }
        }
    }
}
