﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLoadService
{
    public class ParsingService : IParsingService
    {
        //TODO Add more parsing rules
        public decimal? ParseDecimal(string value)
        {
            decimal? close = null;
            decimal closeValue;
            if (Decimal.TryParse(value.ToString(), out closeValue))
            {
                close = closeValue;
            }

            return close;
        }

        public string ParseReturnCharString(string value)
        {
            string name;
            if (value.EndsWith("\r"))
            {
                name = value.Remove(value.Length - 1);
            }
            else
            {
                name = value;
            }

            return name;
        }
    }
}
