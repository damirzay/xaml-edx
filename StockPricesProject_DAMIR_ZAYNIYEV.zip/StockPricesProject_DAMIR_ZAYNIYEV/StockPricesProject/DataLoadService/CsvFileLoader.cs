﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.IO;

namespace DataLoadService
{
    public class CsvFileLoader : IStockPriceLoader
    {
        private readonly string _fileName;
        private readonly string _supplier;
        private readonly IParsingService _parsingService;

        public CsvFileLoader(string filename, string supplier, IParsingService parsingService)
        {
            _fileName = filename;
            _supplier = supplier;
            _parsingService = parsingService;
        }        

        //TODO logic that defines which value comes from which column is hardcode, pass it to method or constructor
        public List<StockPrice> LoadStockPrices()
        {
            var final = new List<StockPrice>();

            string[] data = File.ReadAllText(_fileName).Trim().Split('\n');

            for (int i = 0; i < data.Length; i++)
            {
                if (i == 0)
                    continue;

                string[] values = data[i].Split(',');

                DateTime date = Convert.ToDateTime(values[0]);
                
                Decimal? close = _parsingService.ParseDecimal(values[1]);
                
                string name = _parsingService.ParseReturnCharString(values[2]);                
                
                final.Add(new StockPrice(name, _supplier, close, date));
            }            

            return final;
        }
    }
}
