﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Globalization;

namespace DataLoadService
{
    public class ExcelFileLoader : IStockPriceLoader
    {
        private readonly string _fileName;
        private readonly string _supplier;

        public ExcelFileLoader(string filename, string supplier)
        {
            _fileName = filename;
            _supplier = supplier;
        }

        //TODO pass (to method or constructor) names of columns for each value, if XML file can change in future
        //TODO read and pass (to method or constructor) name of sheet 
        public List<StockPrice> LoadStockPrices()
        {
            var final =  new List<StockPrice>();
                        
            string connectionString = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES""", _fileName);
            //TODO replace hardcode Excel Sheet Name by code that finds its name and used it in instantiation of adapter
            var adapter = new OleDbDataAdapter("SELECT * FROM [StocksPrices-BOB$]", connectionString);
            var ds = new DataSet();

            adapter.Fill(ds, _supplier);
            EnumerableRowCollection<DataRow> data = ds.Tables[_supplier].AsEnumerable();

            foreach (var row in data)
            {
                string name = row["Name"].ToString();
                string dateValue = row["Date"].ToString();

                DateTime date = Convert.ToDateTime(row["Date"]);
                Decimal? close = null;

                //TODO extract this logic to shared parser (parse / load all data types)
                decimal closeValue;
                if(Decimal.TryParse(row["Close"].ToString(), out closeValue))
                {
                    close = closeValue;
                }
                
                final.Add(new StockPrice(name, _supplier, close, date));
            }
            return final;
        }
    }
}
