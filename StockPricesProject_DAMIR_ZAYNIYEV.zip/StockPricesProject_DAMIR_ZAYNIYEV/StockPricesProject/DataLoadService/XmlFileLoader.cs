﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Xml.Linq;
using System.Xml;
using System.IO;

namespace DataLoadService
{
    public class XmlFileLoader : IStockPriceLoader
    {
        private readonly string _fileName;
        private readonly string _supplier;

        public XmlFileLoader(string filename, string supplier)
        {
            _fileName = filename;
            _supplier = supplier;
        }

        //TODO pass (to method or constructor) names of elements for each value, if XML file can change in future
        public List<StockPrice> LoadStockPrices()
        {
            var rows = XElement.Load(_fileName).Elements().Where(p => p.Name.LocalName == "row");

            var final = new List<StockPrice>();

            foreach (var row in rows)
            {
                DateTime date = Convert.ToDateTime(row.Elements().First(p => p.Name.LocalName == "date").Value);
                string name = row.Elements().First(p => p.Name.LocalName == "Name").Value;
                string cloveElementValue = row.Elements().First(p => p.Name.LocalName == "close").Value;

                //TODO extract this logic to shared parser (parse / load all data types)
                Decimal? close = null;
                decimal closeValue;
                if (Decimal.TryParse(cloveElementValue, out closeValue))
                {
                    close = closeValue;
                }

                final.Add(new StockPrice(name, _supplier, close, date));
            }

            return final;
        }
    }
}
