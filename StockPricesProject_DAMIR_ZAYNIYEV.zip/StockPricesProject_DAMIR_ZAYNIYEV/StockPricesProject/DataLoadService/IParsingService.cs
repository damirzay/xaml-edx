﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLoadService
{
    public interface IParsingService
    {
        decimal? ParseDecimal(string v);
        string ParseReturnCharString(string v);
    }
}
