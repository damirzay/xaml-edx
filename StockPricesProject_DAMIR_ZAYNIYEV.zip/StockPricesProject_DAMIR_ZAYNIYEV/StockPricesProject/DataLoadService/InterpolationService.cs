﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace DataLoadService
{
    public class InterpolationService : IInterpolationService
    {
        //TODO implement correct / agreed interpolation, current is simply taking price from previos date
        //As we might have fisrt price (prices) with miss values, for them value is taken from the first existing price in future 
        public void InterpolateStockPrices(List<StockPrice> stockprices)
        {
            var pricesPerTicker = stockprices.GroupBy(x => x.Name);

            foreach (var group in pricesPerTicker)
            {
                group.OrderBy(x => x.Date);
                var fisrtWithPrice = group.Where(x => x.Close.HasValue).First();
                var firstWithMissingPrices = group.Where(x => !x.Close.HasValue && x.Date < fisrtWithPrice.Date);

                foreach (var price in firstWithMissingPrices)
                {
                    price.Close = fisrtWithPrice.Close;
                    price.IsInterpolated = true;
                }
                
                StockPrice prev = group.FirstOrDefault();                

                foreach (var price in group.Skip(1))
                {                    
                    if(!price.Close.HasValue)
                    {
                        price.Close = prev.Close;
                        price.IsInterpolated = true;
                    }                                        
                    prev = price;
                }
            }
        }
    }
}
