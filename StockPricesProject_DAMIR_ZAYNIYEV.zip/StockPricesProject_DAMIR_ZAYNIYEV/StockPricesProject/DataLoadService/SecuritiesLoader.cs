﻿using DataAccesService;
using Entities;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;


namespace DataLoadService
{
    public class SecuritiesLoader : ISecuritiesLoader
    {
        private readonly string _fileName;
        private readonly IStockRepository _stockRepository;

        public SecuritiesLoader(string filename, IStockRepository stockRepository)
        {
            _fileName = filename;
            _stockRepository = stockRepository;
        }

        public void LoadSecurities()
        {
            List<Stock> stocks;
            string Json = File.ReadAllText(_fileName);
            stocks = JsonConvert.DeserializeObject<List<Stock>>(Json);
            
            _stockRepository.SaveStocks(stocks);
        }
    }
}
