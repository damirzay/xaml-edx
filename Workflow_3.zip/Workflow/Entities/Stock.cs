﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    [JsonObject(MemberSerialization.OptIn)]
    public class Stock
    {

        [JsonProperty(PropertyName = "Ticker.symbol")]
        public readonly string Ticker;
        [JsonProperty(PropertyName = "Security")]
        public readonly string Security;
        [JsonProperty(PropertyName = "Sector")]
        public readonly string Sector;
        [JsonProperty(PropertyName = "SubIndustry")]
        public readonly string SubIndustry;

        public Stock()
        {
            //Ticker = ticker;
            //Security = security;
            //Sector = sector;
            //SubIndustry = subIndustry;
        }

        //public Stock(string ticker, string security, string sector, string subIndustry)
        //{
        //    Ticker = ticker;
        //    Security = security;
        //    Sector = sector;
        //    SubIndustry = subIndustry;
        //}
    }
}
