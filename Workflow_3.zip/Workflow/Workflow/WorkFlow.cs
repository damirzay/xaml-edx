﻿using CalculationService;
using DataAccesService;
using DataLoadService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workflow
{
    public class WorkFlow
    {
        private IAllSupplierStockPriceLoader _allSuppliersStockPriceLoader;
        private ISecuritiesLoader _securitiesLoader;
        private IStockRepository _stockRepositary;
        private IInterpolationService _interpolationService;
        private IReturnCalculator _returnCalculator;

        public void Run()
        {
            //TODO use IOC contaner to register Class to interface mappings and to new up instances

            _stockRepositary = new StockRepository();
            _interpolationService = new InterpolationService();

            _allSuppliersStockPriceLoader = new AllSuppliersStockPriceLoader(_stockRepositary, _interpolationService);

            var jsonFile = ConfigurationManager.AppSettings["SECURITIES"];
            _securitiesLoader = new SecuritiesLoader(jsonFile, _stockRepositary);
            _securitiesLoader.LoadSecurities();
                
            _allSuppliersStockPriceLoader.LoadAllSupplierStockPrices();


            DateTime Sdate = DateTime.ParseExact("08/01/2018", "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            DateTime Edate = DateTime.ParseExact("17/01/2018", "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
            var prices = _stockRepositary.GetPricesForSecuritiesForSingleDate(Sdate, null, null, null, null);
            //prices.ContainsKey()

            var prices1 = _stockRepositary.GetPricesForSecurityForDates(Sdate, Edate, "AAL", "alice");
            var prices2 = _stockRepositary.GetPricesForSecurityForDates(Sdate, Edate, "AAL", null);

            _returnCalculator = new ReturnCalculator(_stockRepositary);
            var temp = _returnCalculator.CalculatePriceReturns(Sdate, Edate, null, "alice");
             
        }
    }
}
