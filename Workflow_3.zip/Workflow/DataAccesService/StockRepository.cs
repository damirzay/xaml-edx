﻿using Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesService
{
    public class StockRepository : IStockRepository
    {
        //TODO represents table in SQL db, can be maped using EF
        private List<Stock> _stocks;

        //TODO represents table in SQL db, can be maped using EF
        private List<StockPrice> _stockPrices = new List<StockPrice>();

        private string[] suppliersInOrder;

        public StockRepository()
        {
            //TODO move all retrieval of configurations to seperate configuration service
            var suppliers = ConfigurationManager.AppSettings["SUPPLIERSORDER"];
            suppliersInOrder = suppliers.ToLower().Split(',');
        }

        public void SaveStocks(List<Stock> stocks)
        {
            _stocks = stocks;            
        }

        public void SaveStockPrices(List<StockPrice> stockPrices)
        {
            _stockPrices.AddRange(stockPrices);            
        }


        public List<decimal> GetPricesForSecurityForDates(DateTime startDate, DateTime endDate, string ticker, string supplier = null)
        {
            var allpricesByTickerAndDates = _stockPrices.Where(x => x.Name == ticker)                                                        
                                                        .Where(x => x.Date >= startDate)
                                                        .Where(x => x.Date <= endDate)
                                                        .ToList();

            if (!string.IsNullOrEmpty(supplier))
            {
                Func<StockPrice, bool> isRealPriceFilter = (x) => true;
                return allpricesByTickerAndDates.Where(x => x.Supplier == supplier)
                                                .OrderBy(x => x.Date)
                                                .Select(x => x.Close.Value)
                                                .ToList();                
            }
            else
            {
                return getPricesForAllSuppliers(allpricesByTickerAndDates)
                                            .OrderBy(x => x.Date)
                                            .Select(x => x.Close.Value)
                                            .ToList();
            }
        }

        //TODO come up with generic logic to remove duplicate procedure of obtaining prices for all suppliers
        //Here we deal with different date for the same stock, thus checking other suppliers only for those filtered by Date
        private List<StockPrice> getPricesForAllSuppliers(List<StockPrice> allpricesByTickerAndDates)
        {
            List<StockPrice> pricesPerSupplier = new List<StockPrice>();            

            for (int i = 0; i < suppliersInOrder.Length; i++)
            {
                foreach (var price in allpricesByTickerAndDates.Where(x => x.Supplier == suppliersInOrder[i]))
                {
                    if (price.IsInterpolated == false && !pricesPerSupplier.Any(x => x.Date == price.Date))
                    {
                        pricesPerSupplier.Add(price);
                    }
                }
            }

            foreach (var price in allpricesByTickerAndDates.Where(x => x.Supplier == suppliersInOrder[0]))
            {
                if (price.IsInterpolated == true && !pricesPerSupplier.Any(x => x.Date == price.Date))
                {
                    pricesPerSupplier.Add(price);
                }
            }           

            return pricesPerSupplier;
        }

        public Dictionary<string, decimal> GetPricesForSecuritiesForSingleDate(DateTime priceDate, string ticker=null, string supplier=null, string sector=null, string subIndustry=null)
        {
            Func<StockPrice, bool> dateFilter = (x) => x.Date == priceDate;
            Func<StockPrice, bool> tickerFilter;
            if (ticker == null)
            {
                tickerFilter = (x) => true;
            }
            else
            {
                tickerFilter = (x) => x.Name == ticker;
            }            
            
            Filter filter = new Filter(dateFilter, tickerFilter, sector, subIndustry)
            {
                RealPriceFilter = (x) => true
            };         
            
            if (supplier != null)
            {
                return getPricesFromSupplier(filter, supplier)
                        .ToDictionary(key => key.Name, value => value.Close.Value);
            }
            else
            {
                return getPricesFromAllSuppliers(filter);
            }            
        }       
        
        private List<StockPrice> getPricesFromSupplier(Filter filter, string supplier)
        {
            List<StockPrice> toReturn;
            List<Stock> stocksToReturn;

            //TODO we have to do without join as there 38 securities in prices data that don't exist in Securities data
            //doing join here even on all Securities data will delete 38 securities
            if (string.IsNullOrEmpty(filter.SectorFilter) && string.IsNullOrEmpty(filter.SubIndustryFilter))
            {
                toReturn = _stockPrices.Where(x => x.Supplier == supplier)
                                       .Where(filter.TickerFilter)                                            
                                       .Where(filter.DateFilter)
                                       .Where(filter.RealPriceFilter).ToList();
            }
            else if (string.IsNullOrEmpty(filter.SectorFilter))
            {
                stocksToReturn = _stocks.Where(x => x.SubIndustry == filter.SubIndustryFilter).ToList();

                toReturn = _stockPrices.Where(x => x.Supplier == supplier)
                                       .Where(x => stocksToReturn.Any(y => y.Ticker == x.Name))
                                       .Where(filter.TickerFilter)
                                       .Where(filter.DateFilter)
                                       .Where(filter.RealPriceFilter)
                                       .ToList();
            }
            else
            {
                stocksToReturn = _stocks.Where(x => x.Sector == filter.SectorFilter).ToList();

                toReturn = _stockPrices.Where(x => x.Supplier == supplier)
                                       .Where(x => stocksToReturn.Any(y => y.Ticker == x.Name))
                                       .Where(filter.TickerFilter)
                                       .Where(filter.DateFilter)
                                       .Where(filter.RealPriceFilter)
                                       .ToList();
            }

            return toReturn;   
        }

        //TODO come up with generic logic to remove duplicate procedure of obtaining prices for all suppliers
        //Here we deal with different stocks, thus checking other suppliers only for those filtered by Name
        private Dictionary<string, decimal> getPricesFromAllSuppliers(Filter filter)
        {
            List<StockPrice> pricesPerSupplier = new List<StockPrice>();

            for (int i = 0; i < suppliersInOrder.Length; i++)
            {
                foreach (var price in getPricesFromSupplier(filter, suppliersInOrder[i]))
                {
                    if (price.IsInterpolated == false && !pricesPerSupplier.Any(x => x.Name == price.Name))
                    {
                        pricesPerSupplier.Add(price);
                    }
                }
            }

            foreach (var price in getPricesFromSupplier(filter, suppliersInOrder[0]))
            {
                if (price.IsInterpolated == true && !pricesPerSupplier.Any(x => x.Name == price.Name))
                {
                    pricesPerSupplier.Add(price);
                }
            }            

            //Func<StockPrice, bool> realPriceFilter = (x) => x.IsInterpolated == false;
            //Func<StockPrice, bool> missingPriceFilter = (x) => x.IsInterpolated == true;

            //List<StockPrice> missingPrices = null;
            //for (int i = 0; i < suppliersInOrder.Length; i++)
            //{
            //    filter.RealPriceFilter = realPriceFilter;
            //    pricesPerSupplier.AddRange(getPricesFromSupplier(filter, suppliersInOrder[i], missingPrices));

            //    filter.RealPriceFilter = missingPriceFilter;
            //    missingPrices = getPricesFromSupplier(filter, suppliersInOrder[i], missingPrices);
            //}

            //List<StockPrice> priceMissingInAllSuppliers = new List<StockPrice>();
            //if (missingPrices.Count() > 0)
            //{
            //    filter.RealPriceFilter = (x) => true;
            //    pricesPerSupplier.AddRange(getPricesFromSupplier(filter, suppliersInOrder[0], missingPrices));
            //}

            return pricesPerSupplier.ToDictionary(key => key.Name, value => value.Close.Value);
        }

    }
}
