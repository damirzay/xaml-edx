﻿using System;
using Entities;

namespace DataAccesService
{
    public class Filter
    {
        public readonly Func<StockPrice, bool> DateFilter;

        public readonly Func<StockPrice, bool> TickerFilter;

        public Func<StockPrice, bool> RealPriceFilter { get; set; }

        public readonly string SectorFilter;

        public readonly string SubIndustryFilter;

        public Filter(Func<StockPrice, bool> dateFilter, Func<StockPrice, bool> tickerFilter, string sectorFilter, string subIndustryFilter)
        {
            DateFilter = dateFilter;
            TickerFilter = tickerFilter;
            SectorFilter = sectorFilter;
            SubIndustryFilter = subIndustryFilter;
        }
    }
}
