﻿using DataAccesService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationService
{
    public class ReturnCalculator : IReturnCalculator
    {
        IStockRepository _stockRepository;

        public ReturnCalculator(IStockRepository stockRepository)
        {
            _stockRepository = stockRepository;
        }

        public Dictionary<string, decimal> CalculatePriceReturns(DateTime startDate, DateTime endDate, 
            string ticker = null, string supplier = null, string sector = null, string subIndustry = null)
        {
            Dictionary<string, decimal> startDatePrices = _stockRepository.GetPricesForSecuritiesForSingleDate(startDate, ticker, supplier, sector, subIndustry);
            Dictionary<string, decimal> endDatePrices = _stockRepository.GetPricesForSecuritiesForSingleDate(endDate, ticker, supplier, sector, subIndustry);

            Dictionary<string, decimal> priceReturns = new Dictionary<string, decimal>();

            //Add checking that End Date price exists for stock that has Start Date Price, raise error
            //This check can be moved to validation service
            foreach (var startDatePrice in startDatePrices)
            {
                decimal endDatePrice = endDatePrices[startDatePrice.Key];
                decimal priceReturn = (startDatePrice.Value - endDatePrice) / startDatePrice.Value;
                priceReturns.Add(startDatePrice.Key, priceReturn);
            }

            return priceReturns;
        }
    }
}
