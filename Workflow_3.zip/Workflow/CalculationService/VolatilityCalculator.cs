﻿using DataAccesService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculationService
{
    public class VolatilityCalculator
    {
        IStockRepository _stockRepository;

        public VolatilityCalculator(IStockRepository stockRepository)
        {
            _stockRepository = stockRepository;
        }


        public decimal CalculateVolatility(DateTime startDate, DateTime endDate, string ticker, string supplier = null)
        {
            List<decimal> prices = _stockRepository.GetPricesForSecurityForDates(startDate, endDate, ticker, supplier);


            return 0;
        }
    }
}
