﻿using Entities;
using System.Collections.Generic;


namespace DataLoadService
{
    public interface IStockPriceLoader
    {
       List<StockPrice> LoadStockPrices();
    }   
}
