﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesService
{
    public interface IStockRepository
    {
        void SaveStocks(List<Stock> stocks);

        void SaveStockPrices(List<StockPrice> stockPrices);

        StockPrice GetPriceForSecurityFromSupplier(DateTime date, string ticker, string supplier);

        StockPrice GetPriceForSecurityFromAllSuppliers(DateTime date, string ticker);
    }
}
