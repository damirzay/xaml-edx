﻿using Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesService
{
    public class StockRepository : IStockRepository
    {
        //TODO represents table in SQL db, can be maped using EF
        private List<Stock> _stocks;

        //TODO represents table in SQL db, can be maped using EF
        private List<StockPrice> _stockPrices = new List<StockPrice>();

        private string[] suppliersInOrder;
        
        public void SaveStocks(List<Stock> stocks)
        {
            _stocks = stocks;
            var suppliers = ConfigurationManager.AppSettings["SUPPLIERSORDER"];
            suppliersInOrder = suppliers.ToLower().Split(',');
        }

        public void SaveStockPrices(List<StockPrice> stockPrices)
        {
            _stockPrices.AddRange(stockPrices);            
        }

        public StockPrice GetPriceForSecurityFromSupplier(DateTime date, string ticker, string supplier)
        {
            return _stockPrices.Where(x => x.Date == date && x.Name == ticker && x.Supplier == supplier)
                                        .Select(x => x).FirstOrDefault();
        }

        public StockPrice GetPriceForSecurityFromAllSuppliers(DateTime date, string ticker)
        {
            
            for (int i = 0; i < suppliersInOrder.Length; i++)
            {
                var price = _stockPrices.Where(x => x.Date == date && x.Name == ticker && x.Supplier == suppliersInOrder[i]).FirstOrDefault();
                if(price!=null && !price.IsInterpolated)
                {
                    return price;
                }
            }

            return GetPriceForSecurityFromSupplier(date, ticker, suppliersInOrder[0]);
        }
    }
}
