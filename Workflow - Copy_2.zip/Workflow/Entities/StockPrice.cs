﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class StockPrice
    {
        public readonly string Name;
        public readonly string Supplier;
        public decimal? Close { get; set; }
        public readonly DateTime Date;
        public bool IsInterpolated { get; set; }

        public StockPrice(string name, string supplier, decimal? close, DateTime date)
        {
            Name = name;
            Supplier = supplier;
            Close = close;
            Date = date;
            IsInterpolated = false;
        }
    }
}
