﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using DataLoadService;

namespace Workflow
{
    class Program
    {
       


        static void Main(string[] args)
        {
            WorkFlow wF = new WorkFlow();
            wF.Run();



            //var bob = ConfigurationManager.AppSettings["BOB"];
            //var alice = ConfigurationManager.AppSettings["ALICE"];
            //var charlie = ConfigurationManager.AppSettings["CHARLIE"];
            var jsonFile = ConfigurationManager.AppSettings["SECURITIES"];

            //var excelDataLoader = new ExcelFileLoader(bob);
            //var csvDataLoader = new CsvFileLoader(alice);
            //var xmlDataLoader = new XmlFileLoader(charlie);
            //var jsonLoader = new SecuritiesLoader(jsonFile); 

            //var data = excelDataLoader.LoadStockPrices();
            //var data2 = csvDataLoader.LoadStockPrices();
            //var data3 = xmlDataLoader.LoadStockPrices();

            //var securitites = jsonLoader.LoadSecurities();

            //foreach (var item in securitites)
            //{
            //    Console.WriteLine($"{item.Ticker};  {item.Security};  {item.Sector};  {item.SubIndustry}");
            //}

            //foreach (var item in data3)
            //{
            //    Console.WriteLine($"{item.Name};  {item.Date};  {item.Close}");
            //}
            

            //foreach (var item in data2)
            //{
            //    Console.WriteLine($"{item.Name};  {item.Date};  {item.Close}");
            //}

            //foreach (var item in data)
            //{
            //    Console.WriteLine($"{item.Name};  {item.Date};  {item.Close}");
            //}
        }
    }
}
