﻿using DataAccesService;
using DataLoadService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Workflow
{
    public class WorkFlow
    {
        private IAllSupplierStockPriceLoader _allSuppliersStockPriceLoader;
        private IStockRepository _stockRepositary;
        private IInterpolationService _interpolationService;

        public void Run()
        {
            //TODO use IOC contaner to register Class to interface mappings and to new up instances

            _stockRepositary = new StockRepository();
            _interpolationService = new InterpolationService();

            _allSuppliersStockPriceLoader = new AllSuppliersStockPriceLoader(_stockRepositary, _interpolationService);

            _allSuppliersStockPriceLoader.LoadAllSupplierStockPrices();

        }
    }
}
