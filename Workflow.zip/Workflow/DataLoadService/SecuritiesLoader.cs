﻿using Entities;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;


namespace DataLoadService
{
    public class SecuritiesLoader : ISecuritiesLoader
    {
        private readonly string _fileName;

        public SecuritiesLoader(string filename)
        {
            _fileName = filename;
        }

        public List<Stock> LoadSecurities()
        {
            List<Stock> stocks;
            string Json = File.ReadAllText(_fileName);
            stocks = JsonConvert.DeserializeObject<List<Stock>>(Json);


            //JavaScriptSerializer ser = new JavaScriptSerializer();
            //stocks = ser.Deserialize<List<Stock>>(Json);
            //using (StreamReader r = new StreamReader(_fileName))
            //{
            //    string json = r.ReadToEnd();
            //    stocks = JsonConvert.DeserializeObject<List<Stock>>(json);
            //}

            return stocks;
        }
    }
}
